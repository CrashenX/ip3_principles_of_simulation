package igp3.net.conn;
/***************************************
* Example model created for SIUE
* CS 525/490 - Principles of Simulation
* Spring 2010
* 
* - Dr. Gary Mayer
* - Aaron Jansen
*****************************************/


import java.util.Random;
import GenCol.*;
import model.modeling.*;
import view.modeling.ViewableAtomic;

public class ExpDistGenerator extends ViewableAtomic {
	

	protected Random rand;
	protected double lambda; 
	protected double timeTillNextConnection;
	
	public ExpDistGenerator () {
		// Default lambda = 0.00044391
		this("genr", 0.00044391);
	}
	
	public ExpDistGenerator (String name, double lambda) {
		super(name);
		this.lambda = lambda;
		addOutport("out_connection");
	}
	
	public void initialize () {
		this.rand = new Random();
		timeTillNextConnection = timeUntilNextConnection();
		holdIn("waiting", timeTillNextConnection);
	}
	
	public void  deltext (double e, message x)
	{
		Continue(e);
	}
	
	private double timeUntilNextConnection() {
		// Using the Inverse-Transform Technique to approximate the exponential distribution
		// (-1/lambda) * ln(R) where R is a uniformly generated random variable between 0 and 1
		return ( (-1 / lambda) * Math.log(rand.nextDouble()) );
	}
	
	public void deltint ()
	{
		timeTillNextConnection = timeUntilNextConnection();
		holdIn("waiting", timeTillNextConnection);
	}
	
	public void deltcon (double e, message x) {
		deltext(e,x);
		deltint();
	}
	
	public message out ()
	{
		message  m = new message();
		content con = makeContent("out_connection",new entity(this.name + ":" + timeTillNextConnection));
		m.add(con);
		return m;
	}
	
	public void showState (){
	    super.showState();
	}

	public String getTooltipText (){
		return 
			super.getTooltipText();
	}

}


