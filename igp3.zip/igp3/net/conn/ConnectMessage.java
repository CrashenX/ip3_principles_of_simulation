package igp3.net.conn;

import GenCol.entity;

public class ConnectMessage extends entity {
	boolean http;
	double timeElapsedSinceLastConnection;
	int bytesUp;
	int bytesDown;
	double bpsUp;
	double bpsDown;
	double duration;
	
	
	public ConnectMessage(boolean http, double timeElapsedSinceLastConnection, int bytesUp, int bytesDown,
						double bpsUp, double bpsDown, double duration) {
		if (http)
			name = "http";
		else
			name = "https";

		this.timeElapsedSinceLastConnection = timeElapsedSinceLastConnection;
		this.bytesUp = bytesUp;
		this.bytesDown = bytesDown;
		this.bpsUp = bpsUp;
		this.bpsDown = bpsDown;
		this.duration = duration;
	}
	
}
