package igp3.net.conn;

import view.modeling.ViewableAtomic;
import model.modeling.*;
import java.text.NumberFormat;


public class Transducer extends ViewableAtomic {

	protected double dailyClock;
	protected final double observationTime;
	protected int overlappingConnections;
	protected long totalBytes;
	
	protected long httpTotalBytesUp;
	protected long httpTotalBytesDown;	
	protected double httpTotalBPSUp;
	protected double httpTotalBPSDown;
	protected double httpTotalDuration;
	protected double httpTotalTimeBetweenConnection;
	
	protected long httpsTotalBytesUp;
	protected long httpsTotalBytesDown;	
	protected double httpsTotalBPSUp;
	protected double httpsTotalBPSDown;
	protected double httpsTotalDuration;
	protected double httpsTotalTimeBetweenConnection;
	
	protected long httpCount;
	protected long httpsCount;
	
	
	public Transducer () {
		this("Transducer", 1000.0);
	}
	
	public Transducer (String name, double observationTime) {
		super(name);
		
		this.observationTime = observationTime;
		addInport("in_server");
	}
	
	public void initialize () {
		this.dailyClock = 0.0;
		
		this.httpTotalBytesDown = 0;
		this.httpTotalBytesUp = 0;
		this.httpTotalBPSUp = 0;
		this.httpTotalBPSDown = 0;
		this.httpTotalDuration = 0;
		this.httpTotalTimeBetweenConnection = 0;		
		
		this.httpsTotalBytesDown = 0;
		this.httpsTotalBytesUp = 0;
		this.httpsTotalBPSUp = 0;
		this.httpsTotalBPSDown = 0;
		this.httpsTotalDuration = 0;
		this.httpsTotalTimeBetweenConnection = 0;
		
		this.totalBytes = 0;
		this.overlappingConnections = 0;
		this.httpCount = 0;
		this.httpsCount = 0;
		holdIn("recording", observationTime);
	}
	
	public void deltext (double e, message x) {
		if (phaseIs("recording")) {
			this.dailyClock += e;
			Continue(e);
			
			for (int i=0; i<x.getLength(); i++)
			{
				if (messageOnPort(x, "in_server", i)) 
				{
					ConnectMessage val = (ConnectMessage) x.getValOnPort("in_server", i);
					if(val.getName() == "https")
					{
						// HTTPS
						httpsCount++;
						
						httpsTotalBytesUp += val.bytesUp;
						httpsTotalBytesDown += val.bytesDown;
						httpsTotalBPSUp += val.bpsUp;
						httpsTotalBPSDown += val.bpsDown;
						httpsTotalDuration += val.duration;
						httpsTotalTimeBetweenConnection += val.timeElapsedSinceLastConnection;
						
												
					}
					else
					{
						// HTTP
						httpCount++;
						
						httpTotalBytesUp += val.bytesUp;
						httpTotalBytesDown += val.bytesDown;
						httpTotalBPSUp += val.bpsUp;
						httpTotalBPSDown += val.bpsDown;
						httpTotalDuration += val.duration;
						httpTotalTimeBetweenConnection += val.timeElapsedSinceLastConnection;
					}
				}
			}
		}
	}
	
	public void deltint () {
		this.dailyClock += sigma;
		passivate();
		show_state();
	}
	
	public void deltcon (double e, message x) {
		deltext(e, x);
		deltint();
	}
	
	public message out () {
		return new message();
	}
	
	public void show_state () {
			
		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMinimumFractionDigits(4);		
		nf.setMaximumFractionDigits(4);
		
		System.out.print("state of  "  +  name  +  ": " );
		System.out.println("phase, sigma : " + phase  +  ", "  +  sigma);
		
		double httpAvgBytesUp = httpTotalBytesUp / httpCount;
		double httpAvgBytesDown = httpTotalBytesDown / httpCount;	
		double httpAvgBPSUp = httpTotalBPSUp / httpCount;
		double httpAvgBPSDown = httpTotalBPSDown / httpCount;
		double httpAvgDuration = httpTotalDuration / httpCount;
		double httpAvgTimeBetweenConnection = httpTotalTimeBetweenConnection / httpCount;
		
		double httpsAvgBytesUp = httpsTotalBytesUp / httpsCount;
		double httpsAvgBytesDown = httpsTotalBytesDown / httpsCount;	
		double httpsAvgBPSUp = httpsTotalBPSUp / httpsCount;
		double httpsAvgBPSDown = httpsTotalBPSDown / httpsCount;
		double httpsAvgDuration = httpsTotalDuration / httpsCount;
		double httpsAvgTimeBetweenConnection = httpsTotalTimeBetweenConnection / httpsCount;
	
		System.out.println("HTTP");
		System.out.println("");	
		System.out.println("Avg Bytes Up: " + nf.format(httpAvgBytesUp));
		System.out.println("Avg Bytes Down: " + nf.format(httpAvgBytesDown));
		System.out.println("Avg BPS Up: " + nf.format(httpAvgBPSUp));
		System.out.println("Avg BPS Down: " + nf.format(httpAvgBPSDown));
		System.out.println("Avg Duration: " + nf.format(httpAvgDuration));
		System.out.println("Avg Time b/t Connections: " + nf.format(httpAvgTimeBetweenConnection));
		
		System.out.println("");	
		System.out.println("");	
		
		System.out.println("HTTPS");
		System.out.println("");	
		System.out.println("Avg Bytes Up: " + nf.format(httpsAvgBytesUp));
		System.out.println("Avg Bytes Down: " + nf.format(httpsAvgBytesDown));
		System.out.println("Avg BPS Up: " + nf.format(httpsAvgBPSUp));
		System.out.println("Avg BPS Down: " + nf.format(httpsAvgBPSDown));
		System.out.println("Avg Duration: " + nf.format(httpsAvgDuration));
		System.out.println("Avg Time b/t Connections: " + nf.format(httpsAvgTimeBetweenConnection));	
		
	}
	
	
	 
}

