package igp3.net.conn;

import java.util.Random;

import model.modeling.content;
import model.modeling.message;
import GenCol.entity;
import view.modeling.ViewableAtomic;
import igp3.net.conn.ConnectMessage;
import igp3.net.conn.Distribution;

public class Server extends ViewableAtomic {
	protected Random rand;
	protected int totalBytes; 
	protected double lamda;
	
	Distribution dist;
	
	boolean http;
	double timeElapsedSinceLastConnection;
	int bytesUp;
	int bytesDown;
	double bpsUp;
	double bpsDown;
	double duration;
	
	
	public Server () {
		// Default lambda = 0.00044391
		this("Server");
	}
	
	public Server (String name) {
		super(name);
		addInport("request");
		addOutport("out_transducer");
	}
	
	public void initialize () {
		this.rand = new Random();
		this.dist = new Distribution();
		
		this.totalBytes = 0;
		this.lamda = 0.00017382;
		holdIn("waiting", INFINITY);
	}
	
	public void  deltext (double e, message x)
	{
		Continue(e);
		for(int i=0;i<x.getLength();i++)
		{
			entity val = x.getValOnPort("request", i);
			if(val.getName().startsWith("https"))
			{
				// HTTPS
				http = false;

				// find random values based on the appropriate distributions
				totalBytes = (int)(dist.calc_tot_bytes_https());
				bytesDown = (int)(totalBytes * dist.calc_perc_down_https());
				bpsDown = dist.calc_bps_down_https();
				
				// calculate other values based on the distributed values
				bytesUp = totalBytes - bytesDown;
				// set minimum values
				if(bytesDown <= 0) bytesDown = 1;
				if(bytesUp   <= 0) bytesUp   = 1;
				if(bpsDown   <= 0) bpsDown   = 1;
				
				duration = (double)(bytesDown * 8) / bpsDown;
				bpsUp = (double)((bytesUp * 8) / duration);
				
				timeElapsedSinceLastConnection = Double.parseDouble(val.getName().split(":")[1]);
				
			}
			else
			{
				// HTTP
				http = true;

				// find random values based on the appropriate distributions
				totalBytes = (int)(dist.calc_tot_bytes_http());
				bytesDown = (int)(totalBytes * dist.calc_perc_down_http());
				bpsDown = dist.calc_bps_down_http();
				
				// calculate other values based on the distributed values
				bytesUp = totalBytes - bytesDown;
				// set minimum values
				if(bytesDown <= 0) bytesDown = 1;
				if(bytesUp   <= 0) bytesUp   = 1;
				if(bpsDown   <= 0) bpsDown   = 1;
				
				duration = (double)(bytesDown * 8) / bpsDown;
				bpsUp = (double)((bytesUp * 8) / duration);
				
				timeElapsedSinceLastConnection = Double.parseDouble(val.getName().split(":")[1]);
				
			}
		}
		
		holdIn("send", 0);
	}
	
	public void deltint ()
	{
		holdIn("waiting", INFINITY);
	}
	
	public void deltcon (double e, message x) {
		deltext(e,x);
		deltint();
	}
	
	public message out ()
	{
		message  m = new message();
		
		content con = makeContent("out_transducer", new ConnectMessage(http, timeElapsedSinceLastConnection, bytesUp, bytesDown, bpsUp, bpsDown, duration));
		m.add(con);

		return m;
	}
	
	public void showState (){
	    super.showState();
	}

	public String getTooltipText (){
		return 
			super.getTooltipText();
	}

}





